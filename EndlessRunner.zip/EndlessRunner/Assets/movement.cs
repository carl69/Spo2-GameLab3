﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement : MonoBehaviour {
    public Rigidbody rb;
	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKey(KeyCode.D))
        {
            transform.position += new Vector3(20 * Time.deltaTime, 0, 0);

            if (transform.rotation.eulerAngles.y != 0)
            {
                Debug.Log(transform.rotation);

                transform.localEulerAngles = new Vector3(0, 0, 0);
            }
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.position += new Vector3(-20 * Time.deltaTime, 0, 0);
            if (transform.rotation.eulerAngles.y != 180) 
            {
                Debug.Log(transform.rotation);

                transform.localEulerAngles = new Vector3(0, 180, 0);
            }
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(transform.up * 1000);
        }
    }
    private void FixedUpdate()
    {
        GetComponent<Rigidbody>().AddForce(Physics.gravity*2f, ForceMode.Acceleration);
    }
}
